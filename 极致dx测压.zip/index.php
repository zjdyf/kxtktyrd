<?PHP
 header("Location: ./user\n");
?>