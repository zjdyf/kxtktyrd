<?php
$mod='blank';
include("../includes/common.php");
$title='后台管理';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

$gls=$DB->count("SELECT count(*) from msg_log WHERE 1");
?><script language="javascript">
var Words ="%20%20%3Cdiv%20class%3D%22container%22%20style%3D%22padding-top%3A70px%3B%22%3E%0A%20%20%20%20%3Cdiv%20class%3D%22col-xs-12%20col-sm-10%20col-lg-8%20center-block%22%20style%3D%22float%3A%20none%3B%22%3E%0A%20%20%20%20%20%20%3Cdiv%20class%3D%22panel%20panel-primary%22%3E%0A%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22panel-heading%22%3E%3Ch3%20class%3D%22panel-title%22%3E后台管理%3C/h3%3E%3C/div%3E%0A%20%20%20%20%20%20%20%20%20%20%20%3Cli%20class%3D%22list-group-item%22%3E%3Cspan%20class%3D%22glyphicon%20glyphicon-time%22%3E%3C/span%3E%20%3Cb%3E现在时间：%3C/b%3E%20%3C%3F%3D%24date%3F%3E%3C/li%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%3C/ul%3E%0A%20%20%20%20%20%20%20%20%20%20%3Cli%20class%3D%22list-group-item%22%3E%3Cspan%20class%3D%22glyphicon%20glyphicon-check%22%3E%3C/span%3E%20%3Cb%3E程序版本：%3C/b%3E%20V1.66%3C/li%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%3C/ul%3E%20%20%20%0A%20%20%20%20%20%20%20%20%20%20%3Cli%20class%3D%22list-group-item%22%3E%3Cspan%20class%3D%22glyphicon%20glyphicon-check%22%3E%3C/span%3E%20%3Cb%3E版权：%3C/b%3E极致%3C/li%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%3C/ul%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cli%20class%3D%22list-group-item%22%3E%3Cspan%20class%3D%22glyphicon%20glyphicon-pencil%22%3E%3C/span%3E%20%3Cb%3E%3Ca%20href%3D%22./set.php%22%20class%3D%22btn%20btn-default%20btn-sm%22%3E账户设置%3C/a%3E%20%3Ca%20href%3D%22./add.php%22%20class%3D%22btn%20btn-default%20btn-sm%22%3E添加接口%3C/a%3E%20%0A%20%20%20%20%3C/div%3E" 
function OutWord()
{
var NewWords;
NewWords = unescape(Words);
document.write(NewWords);
}
OutWord();
</script>

    </div>
  </div>
