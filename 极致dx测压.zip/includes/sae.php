<?php
/*数据库配置*/
$dbconfig=array(
	'host' => SAE_MYSQL_HOST_M, //数据库服务器
	'port' => SAE_MYSQL_PORT, //数据库端口
	'user' => SAE_MYSQL_USER, //数据库用户名
	'pwd' => SAE_MYSQL_PASS, //数据库密码
	'dbname' => SAE_MYSQL_DB, //数据库名
	'dbqz' => 'wjob' //数据表前缀
);
?>