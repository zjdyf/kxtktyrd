<?php

$title='后台管理';
include './head.php';
include("../includes/common.php"); 
$row=$DB->get_row("SELECT * FROM user_list WHERE user='".$_SESSION['user']."'");
?>
<main class="lyear-layout-content">
<div class="container-fluid"><?php
if(isset($_POST['submit'])) {
	$pass=daddslashes($_POST['pass']);
	$qq=daddslashes($_POST['qq']);
	$sql="update`user_list` set `pass` ='{$pass}', `qq` ='{$qq}'  where `user`='{$_SESSION['user']}'";
	if(!empty($pwd))$DB->query("update `user_list` set `key` ='{$key}',  `qq` ='{$qq}' where `user`='{$_SESSION['user']}'");
	if($DB->query($sql))showmsg('修改成功！',1);
	else showmsg('修改失败！<br/>'.$DB->error(),4);
}else{ 
?>
</head>
<body>
    <div class="page-top">
        <h4 id="title"><?php echo $conf["title"] ?></h4>
    </div>
    <div class="page-nav" id="a" style="">
        <div class="space-20"></div>
                    <a href="." class="btn btn-success">呼叫</a>
            &nbsp;
                    <a href="/user/km.php" class="btn btn-warning">充值</a>
        &nbsp;
                    <a href="/user/log.php" class="btn btn-danger">记录</a>
        &nbsp;
            <a href="login.php?logout" class="btn btn-default logout">退出</a>        <div class="space-20"></div>
    </div>
<p class="page-title">信息修改</p>
<div class="page-content">
    <div class="row">
        <div class="col-sm-12">
            <div class="space-10"></div></div>
    <form action="./set.php" method="post"  role="form">
      <div class="form-group">
                    <label for="" class="col-sm-2 control-label">帐号</label>
                    <div class="col-sm-10">
           <input type="text" name="" readonly  value="<?php echo $_SESSION['user']; ?>" class="form-control" required/></div>
        </div>
      <div class="form-group">
                    <label for="" class="col-sm-2 control-label">QQ</label>
                    <div class="col-sm-10"><input type="number" name="qq"  value="<?php echo $row['qq'] ?>" class="form-control" required/></div>
	</div><br/>
      <div class="form-group">
                    <label for="" class="col-sm-2 control-label">密码</label>
                    <div class="col-sm-10"><input type="text" name="pass"  value="<?php echo $row['pass'] ?>" class="form-control" required/></div>
</div><br/>
<div class="form-group">
            <div class="col-sm-10 col-sm-offset-2">
                <input type="submit" name="submit" value="修改" class="btn btn-warning btn-block">
            </div>
	 </div>
	</div>
  </form>
</div>
</div>
<?php } ?>
      <footer class="col-sm-12 text-center">
       
      </footer>
<script type="text/javascript" src="static/js/jquery.min.js"></script>
</body>
</html>
<script type="text/javascript" src="static/js/jquery.min.js"></script>
<script type="text/javascript" src="static/js/bootstrap.min.js"></script>
    <!-- Sweet alert -->
    <script src="static/js/sweetalert.min.js"></script>
    <script type="text/javascript" src="static/js/common.js"></script>
    </body>
</html>