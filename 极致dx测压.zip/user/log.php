<?php
$title='后台管理';
include './head.php';
include("../includes/common.php"); 
$row=$DB->get_row("SELECT * FROM user_list WHERE user='".$_SESSION['user']."'");
?>
</head>
<body>
    <div class="page-top">
        <h4 id="title"><?php echo $conf["title"] ?></h4>
    </div>
    <div class="page-nav" id="a" style="">
        <div class="space-20"></div>
                    <a href="." class="btn btn-success">呼叫</a>
            &nbsp;
                    <a href="/user/km.php" class="btn btn-warning">充值</a>
        &nbsp;
                    <a href="/user/log.php" class="btn btn-danger">记录</a>
        &nbsp;
            <a href="login.php?logout" class="btn btn-default logout">退出</a>        <div class="space-20"></div>
    </div>
<p class="page-title">轰炸日志</p>
<div class="page-content">
    <div class="row">
    <div class="col-sm-12">
</div>
<div class="card-body">
<div class="table-responsive">
<table class="table table-hover">
<thead>
<tr>
<th>帐号</th>
<th>呼号</th>
<th>金额</th>
<th>IP</th>
<th>时间</th>
</tr>
</thead>
<tbody>
<?php
$pagesize=10;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);

$rs=$DB->query("SELECT * FROM msg_log WHERE user=\"".$row['user']."\" order by id desc limit $offset,$pagesize");
while($res = $DB->fetch($rs))
{
echo '<td>'.$res['user'].'</td><td>'.$res['phone'].'</td><td>'.$res['money'].'</td><td>'.$res['ip'].'</td><td>'.$res['date'].'</td></tr>';
}
?>
</td>
</tr>
</tbody>
</table>
</div>
<center>
<?php
echo'<ul class="pagination">';
$s = ceil($gls / $pagesize);
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$s;
if ($page>1)
{
echo '<li><a href="log.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="log.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="log.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$s;$i++)
echo '<li><a href="log.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$s)
{
echo '<li><a href="log.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="log.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
?>
      <footer class="col-sm-12 text-center">
        
      </footer>
<script type="text/javascript" src="static/js/jquery.min.js"></script>
</body>
</html>
<script type="text/javascript" src="static/js/jquery.min.js"></script>
<script type="text/javascript" src="static/js/bootstrap.min.js"></script>
    <!-- Sweet alert -->
    <script src="static/js/sweetalert.min.js"></script>
    <script type="text/javascript" src="static/js/common.js"></script>
    </body>
</html>
