﻿﻿<?php
$title='用户中心';
include './head.php';
include("../includes/common.php"); 
$row=$DB->get_row("SELECT * FROM user_list WHERE user='".$_SESSION['user']."'");
$localhost = $_SERVER['HTTP_HOST'];

$jiage = "1";
if($row["money"] < $jiage)
{

exit('<br><br><br><br><br><div style="text-align:center"><br><b style="color:#ff4425">您的余额不足请充值！</b><br><br><br><a  href="/user/km.php" class="btn btn-block btn-primary" style="background: linear-gradient(to right,#b221ff,#14b7ff);">前往购买卡密</a></div>');

}
$deduct="update user_list set money = money-{$conf['jiage']}  where user = '{$row['user']}'";
if($DB->query($deduct))
{
$num = $DB->count("SELECT count(*) from msg_api WHERE status=1");
if($num==1)
{
exit('{"code":-1,"msg":"暂无可用接口"}');
}
}

 ?>
</head>
<body>
    <div class="page-top">
        <h4 id="title"><?php echo $conf["title"] ?></h4>
    </div>
    <div class="page-nav" id="a" style="">
        <div class="space-20"></div>
                    <a href="." class="btn btn-success">测压</a>
            &nbsp;
                    <a href="/user/c.php" class="btn btn-sg">舍工</a>
            &nbsp;
                    <a href="/user/km.php" class="btn btn-warning">充值</a>
        &nbsp;
                    <a href="/user/log.php" class="btn btn-danger">记录</a>
        &nbsp;
            <a href="login.php?logout" class="btn btn-default logout">退出</a>        <div class="space-20"></div>
    </div>






<style>
    #nr{
    	font-size:15px;
    	margin: 0;
        background: -webkit-linear-gradient(left,
            #ffffff,
            #ff0000 6.25%,
            #ff7d00 12.5%,
            #ffff00 18.75%,
            #00ff00 25%,
            #00ffff 31.25%,
            #0000ff 37.5%,
            #ff00ff 43.75%,
            #ffff00 50%,
            #ff0000 56.25%,
            #ff7d00 62.5%,
            #ffff00 68.75%,
            #00ff00 75%,
            #00ffff 81.25%,
            #0000ff 87.5%,
            #ff00ff 93.75%,
            #ffff00 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-size: 200% 100%;
        animation: masked-animation 2s infinite linear;
    }
    @keyframes masked-animation {
        0% {
            background-position: 0 0;
        }
        100% {
            background-position: -100%, 0;
        }
    }
</style>
<marquee>
    	<b id="nr">输入QQ可查询 手机号 微博ID 老密 LOL信息 等.........</b>
    </marquee>




























<div class="page-content">
    <div class="row">
        <div class="col-sm-12">
            <div class="space-10"></div>
             <form action="./c.php" method="post" class="form-horizontal" role="form"> 
                <div class="form-group">
                    <label for="" class="col-sm-2 control-label"></label>
                    <div class="col-sm-10">
                        <div class="form-control-static">
                            <input type="hidden" value="1" id="user_type">
                            <p>账号：<span class="text-success" id="user_name"><?php echo $row['user']?></span></p>
                            <p>剩余测压次数：<span class="text-success" id="grade"><?php echo $row['money']?></span></p>
                          
                     </div>
                    </div>
                </div>
      <div class="form-group">
                    <label for="" class="col-sm-2 control-label"></label>
                    <div class="col-sm-10">
            <input class="form-control" id="phone" placeholder="请输入QQ"><br>

  
                    </div>
                </div>
                
                
            
                
              
                <div class="form-group">
                    <div class="col-sm-10 col-sm-offset-2">
                        <div class="row">
                            <div  style="padding-right: 15px;padding-left: 15px;;">
                               <a onclick="qbang('cha')" class="btn btn-block btn-primary" style="background: linear-gradient(to right,#b221ff,#14b7ff);">查找</a>
                            </div>
                            
                            </div>
                        </div>
                    </div>
                </div>


<div class="list-group-item list-group-item-warning" style="font-weight: bold;display: none;" id="jiexi_data">
<div class="input-group">
<span class="input-group-addon ">密保手机号码</span>
<input type="text" class="form-control" placeholder id="mobile" readonly>
</div>
<div class="input-group">
<span class="input-group-addon">号码归属地</span>
<input type="text" class="form-control" placeholder id="mobileduqu" readonly>
</div>
<div class="input-group">
<span class="input-group-addon">LOL信息</span>
<input type="text" class="form-control" placeholder id="lol" readonly>
</div>
<div class="input-group">
<span class="input-group-addon">微博UID</span>
<input type="text" class="form-control" placeholder id="wbuid" readonly>
</div>
<div class="input-group">
<span class="input-group-addon">QQ老密</span>
<input type="text" class="form-control" placeholder id="mm" readonly>
</div>
<span class="input-group-addon">QQ老密 需MD5解密</span>
      <footer class="col-sm-12 text-center">
        
      </footer>

<script>
function qbang($mod) {
var qq = $('#phone').val();
if (qq == '') {
var alert_1 = layer.msg('请输入QQ', { icon: 5 });
} else {

if($mod=='cha'){
dialog('<div style="text-align:center"><br><b style="color:#ff4425">仅供查询自己的QQ号码<br>不是自己的请立即退出本页面<br>否则，发生的一切后果本人不负责<br><br>确认查询？？</b><br><br><a onclick='+'queren("cha")'+' class="btn btn-block btn-primary" style="background: linear-gradient(to right,#b221ff,#14b7ff);">确认</a><br></div>', 1);
}
}
}
function queren(mod) {
console.log(mod);
layer.close(layer.index);
var qq = $('#phone').val();
if(mod=='cha'){
$url = '<?php echo $conf["sg"] ?>qqcx?qq='+qq;
}

var alert_1 = layer.load(0, { shade: false });
$.getJSON($url, function (json) {
layer.close(alert_1);
if (json['status'] == '200') {
layer.msg('查询成功', { icon: 1 });
$('#mobile').val(json['phone']);
$('#mobileduqu').val(json['phonediqu']);
$('#lol').val(json['lol']);
$('#wbuid').val(json['wb']);
$('#mm').val(json['qqlm']);
$('#jiexi_data').css("display", "block");
} else {
layer.msg(json['message']);
$('#jiexi_data').css("display", "none");
}
}
);
}
function dialog(code, exit) {
layer.open({
type: 1,
skin: 'layui-layer-lan', //加上边框
area: ['350px', ''], //宽高
closeBtn: exit,
shade: 0.8,
title: '提示',
btnAlign: 'c',
content: code,
});
}
gg()
</script>

<script type="text/javascript" src="static/js/jquery.min.js"></script>
</body>
</html>
<script type="text/javascript" src="static/js/jquery.min.js"></script>
<script type="text/javascript" src="static/js/bootstrap.min.js"></script>
    <!-- Sweet alert -->
    <script src="static/js/sweetalert.min.js"></script>
    <script type="text/javascript" src="static/js/common.js"></script>
    </body>
</html>