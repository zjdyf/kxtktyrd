<!-- 看你大爷
 ================================
// +----------------------------+
// | 看你大爷
// +----------------------------+
// | 看你大爷
// +----------------------------+
// | 看你大爷
// +----------------------------+
// | 看你大爷
// +----------------------------+
=================================
--> 
<?php
/**
 * 用户注册
**/
@header('Content-Type: text/html; charset=UTF-8');
include("../includes/common.php");
?>
<!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title><?php echo $conf["title"] ?>-注册</title>
	<link rel="stylesheet" href="css/register.css">
</head>
<body>
	<div class="login">
		
		<div class="title">
			<?php echo $conf["title"] ?>-注册
		</div>
		<form action="./reg.php" method="POST" role="form">
		<div class="user">
			<input type="text" name="user" value="<?php echo @$_POST['user']?>" placeholder="请输入账号"><span></span>
		</div>
		<div class="pass">
			<input type="password" name="pass" placeholder="请输入密码">
		</div>
		<div class="mailbox">
			<input type="number" name="qq" placeholder="请输入QQ">
		</div>
		<div class="pass">
			<input type="text" name="code" id="code_input" placeholder="请输入验证码"><br><br><center><img src="./code.php?r=<?php echo time();?>"height="32"onclick="this.src='./code.php?r='+Math.random();" title="点击更换验证码"></center>
		</div>
		<div class="button">
			<button type="submit" name="submit">立即注册<span></span></button>
		</div>
		<div class="register">
			<div class="registers"><a href="login.php" >返回登录</a></div>
		
		</div>
		</form>
	</div>
	<footer>
		
	</footer>
</body>
</html>
<?php
$user = $_POST['user'];
$pass = $_POST['pass']; 
$qq = $_POST['qq'];

if(!$user || !$pass || !$qq)
{}
else
{
if(isset($_POST['qq']) && isset($_POST['user']) && isset($_POST['pass'])){
$qq=daddslashes($_POST['qq']);
$user=daddslashes($_POST['user']);
$pass=daddslashes($_POST['pass']);
$code=daddslashes($_POST['code']);
if(!$code || strtolower($_SESSION['mulin_code'])!=strtolower($code)){exit("<script language='javascript'>alert('验证码错误');window.location.href='./reg.php';</script>");

}
if(number($conf["zsye"]))
{
$money = $conf["zsye"];
}
else
{
$money = '0';
}
//$key = random("18");
$row=$DB->get_row("SELECT * FROM user_list WHERE user='{$user}' limit 1");
if($row!='')exit("<script language='javascript'>alert('该账号已经注册！');window.location.href='./reg.php';</script>");
$key = random("18");
	$sql="insert into `user_list` (`qq`,`user`,`pass`,`money`,`key`,`status`) values ('$qq','$user','$pass','$money','$key','0')";
	$DB->query($sql);
echo "<script language='javascript'>alert('注册成功！');window.location.href='./';</script>";
}
}


?>
      <footer class="col-sm-12 text-center">
     
      </footer>
<script type="text/javascript" src="static/js/jquery.min.js"></script>
</body>
</html>
<script type="text/javascript" src="static/js/jquery.min.js"></script>
<script type="text/javascript" src="static/js/bootstrap.min.js"></script>
    <!-- Sweet alert -->
    <script src="static/js/sweetalert.min.js"></script>
    <script type="text/javascript" src="static/js/common.js"></script>
    </body>
</html>