<!-- 看你大爷
 ================================
// +----------------------------+
// | 看你大爷看你大爷看你大爷
// +----------------------------+
// | 看你大爷看你大爷
// +----------------------------+
// | 看你大爷
// +----------------------------+
// | 看你大爷
// +----------------------------+
=================================
--> 
<?php
@header('Content-Type: text/html; charset=UTF-8');
include("../includes/common.php");
$mod='blank';
if($_SESSION['islogin']==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
$row=$DB->get_row("SELECT * FROM user_list WHERE user='".$_SESSION['user']."'");
if($row["status"]=='0'){
}
else
{
exit(sysmsg('当前帐户已被封禁<br/>详情请咨询QQ:'.$conf['qq']."<br/>请后续规范使用！"));
}
?>
<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<title><?php echo $conf["title"] ?> - <?php echo $title ?></title>
<link rel="icon" href="../assets/LightYear/favicon.ico" type="image/ico">
<meta name="keywords" content="<?php echo $conf["title"] ?>,全网最好用的短信轰炸框架"/>
<meta name="description" content="<?php echo $conf["title"] ?>,虚拟主机,服务器都可以安全运行。！"/>
<meta name="author" content="icools">
<link rel="stylesheet" href="static/css/bootstrap.min.css"/>
<link rel="stylesheet" href="static/css/font-awesome.min.css"/>
<link rel="stylesheet" href="static/css/bootstrap-theme.css"/>
<link href="static/css/sweetalert.css" rel="stylesheet">
<script src="//lib.baomitu.com/jquery/1.12.4/jquery.min.js"></script>
<script src="//lib.baomitu.com/layer/2.3/layer.js"></script> 
<script src="../assets/layer.js"></script>
</head>
<script language="javascript">
function logout(){
if( confirm("你确实要退出吗？")){
window.parent.location.href="login.php?logout";
}
else{
return;
}
}
</script>  