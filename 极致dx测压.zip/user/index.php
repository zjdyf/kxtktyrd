<?php
$title='用户中心';
include './head.php';
include("../includes/common.php"); 
$row=$DB->get_row("SELECT * FROM user_list WHERE user='".$_SESSION['user']."'");
$localhost = $_SERVER['HTTP_HOST'];

function alert($tips)
{
return '<script>layer.alert("'.$tips.'");</script>';
}
$phone = $_POST["phone"];
if($phone)
{
$url = 'http://'.$localhost.'/api.php?act=msg&syskey='.$conf['syskey'].'&user='.$_SESSION['user'].'&phone='.$phone.'&ip='.real_ip();
$data = json_decode(get_curl($url),true);
if($data['code']=='-1')
{
echo(alert($data['msg']));
}
else
{
echo(alert('短信轰炸执行成功！'));
}
}

 ?>
</head>
<body>
    <div class="page-top">
        <h4 id="nr"><font size="4px">极致测压中心</font></h4>
    </div>
    <div class="page-nav" id="a" style="">
        <div class="space-20"></div>
                    <a href="." class="btn btn-success">测压</a>
            &nbsp;
                    <a href="/user/c.php" class="btn btn-sg">舍工</a>
            &nbsp;
                    <a href="/user/km.php" class="btn btn-warning">充值</a>
        &nbsp;
                    <a href="/user/log.php" class="btn btn-danger">记录</a>
        &nbsp;
            <a href="login.php?logout" class="btn btn-default logout">退出</a>        <div class="space-20"></div>
    </div>

<style>
    #nr{
    	font-size:15px;
    	margin: 0;
        background: -webkit-linear-gradient(left,
            #ffffff,
            #ff0000 6.25%,
            #ff7d00 12.5%,
            #ffff00 18.75%,
            #00ff00 25%,
            #00ffff 31.25%,
            #0000ff 37.5%,
            #ff00ff 43.75%,
            #ffff00 50%,
            #ff0000 56.25%,
            #ff7d00 62.5%,
            #ffff00 68.75%,
            #00ff00 75%,
            #00ffff 81.25%,
            #0000ff 87.5%,
            #ff00ff 93.75%,
            #ffff00 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-size: 200% 100%;
        animation: masked-animation 2s infinite linear;
    }
    @keyframes masked-animation {
        0% {
            background-position: 0 0;
        }
        100% {
            background-position: -100%, 0;
        }
    }
</style>
<marquee>
    	<b id="nr">欢迎来到<?php echo $conf["title"] ?>&nbsp;&nbsp;&nbsp;可通过Q查手机号等&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;建议收藏本站防止迷路！</b>
    </marquee>




<div class="page-content">
    <div class="row">
        <div class="col-sm-12">

             <form action="./index.php" method="post" class="form-horizontal" role="form"> 
                <div class="form-group">
                    <label for="" class="col-sm-2 control-label"></label>
                    <div class="col-sm-10">
                        <div class="form-control-static">
                            <input type="hidden" value="1" id="user_type">
                            <p>账号：<span class="text-success" id="user_name"><?php echo $row['user']?></span></p>
                            <p>剩余测压次数：<span class="text-success" id="grade"><?php echo $row['money']?></span></p>
                          
                     </div>
                    </div>
                </div>
      <div class="form-group">
                    <label for="" class="col-sm-2 control-label"></label>
                    <div class="col-sm-10">
             <input type="text" name="phone" placeholder="请输入要轰炸的手机号" class="form-control" required/><br>

  <center>
			 <a href="http://47.111.175.54:81/?cid=2&tid=2"><font align="center" color="red">输入手机号点击开始测压即可<br>若测压次数为0可点我测试效果</font></a></center>
                    </div>
                </div>
                
                
            
                
              
                <div class="form-group">
                    <div class="col-sm-10 col-sm-offset-2">
                        <div class="row">
                            <div class="col-xs-6" style="padding-right: 7px;">
                                <button type="submit" name="submit" class="btn btn-block btn-success start">
                                    <i class="fa fa-play-circle-o"></i> 开始测压
                                </button>
                            </div>
                            <div class="col-xs-6" style="padding-left: 7px;">
                                <button type="submit"  onclick="top.location='index.php"  class="btn btn-block btn-danger stop" disabled="disabled">
                                    <i class="fa fa-stop-circle-o"></i> 停止测压
                                </button>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
      <footer class="col-sm-12 text-center">
        
      </footer>
<script type="text/javascript" src="static/js/jquery.min.js"></script>
</body>
</html>
<script type="text/javascript" src="static/js/jquery.min.js"></script>
<script type="text/javascript" src="static/js/bootstrap.min.js"></script>
    <!-- Sweet alert -->
    <script src="static/js/sweetalert.min.js"></script>
    <script type="text/javascript" src="static/js/common.js"></script>
    </body>
</html>