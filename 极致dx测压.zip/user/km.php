<?php
$title='卡密充值';
include './head.php';
include("../includes/common.php"); 
$row=$DB->get_row("SELECT * FROM user_list WHERE user='".$_SESSION['user']."'");
$localhost = $_SERVER['HTTP_HOST'];

function alert($tips)
{
return '<script>layer.alert("'.$tips.'");</script>';
}
$km = $_POST["km"];
if($km)
{
$res=$DB->get_row("SELECT * FROM msg_km WHERE km='".$_POST['km']."'");
if($res)
{
if($res["status"]==0)
{
$money = $res['money'];//卡密值

$deduct="update msg_km set status=1 where km='{$_POST['km']}'";
$DB->query($deduct);

$deduct="update user_list set money = money+{$money}  where user = '{$_SESSION['user']}'";
$DB->query($deduct);
echo alert('卡密充值成功，面额:'.$money."元");
}else
{
echo alert("卡密已被使用");
}
}
else
{
echo alert("卡密不存在");
}
}

 ?>
</head>
<body>
    <div class="page-top">
        <h4 id="title"><?php echo $conf["title"] ?></h4>
    </div>
    <div class="page-nav" id="a" style="">
        <div class="space-20"></div>
                    <a href="." class="btn btn-success">测压</a>
            &nbsp;
         <a href="/user/c.php" class="btn btn-sg">舍工</a>
            &nbsp;
                    <a href="/user/km.php" class="btn btn-warning">充值</a>
        &nbsp;
                    <a href="/user/log.php" class="btn btn-danger">记录</a>
        &nbsp;
            <a href="login.php?logout" class="btn btn-default logout">退出</a>        <div class="space-20"></div>
    </div>
    <p class="page-title">购买</p>
    <div class="page-content">
        <div class="row">
            <div class="col-sm-12">
    <div class="space-10"></div>
     <form action="./km.php" method="post" class="form-horizontal" role="form"> 
        <div class="form-group">
            <label class="control-label col-sm-2">账号</label>
            <div class="col-sm-10">
                <input type="text" name="name" id="username" value="<?php echo $row['user']?>" class="form-control" placeholder="请输入账号">
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col-sm-2">卡密</label>
            <div class="col-sm-10">
                <div class="input-group">
                    <input class="form-control" name="km" type="text"   placeholder="请输入充值卡">
                    <div class="input-group-btn"><button type="submit" class="btn btn-success updateadmin" >提交</button></div>
                </div>

            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-10 col-sm-offset-2">
                <a  id="href"  class="btn btn-warning btn-block" target="_blank" href="http://47.111.175.54:81/?cid=2">客服QQ <?php echo $conf["qq"] ?> 购买卡密 </a>
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-10 col-sm-offset-2">
               
            </div>
            </div>
        </div>
    </div>
</div>
      <footer class="col-sm-12 text-center">
       
      </footer>
<script type="text/javascript" src="static/js/jquery.min.js"></script>
</body>
</html>
<script type="text/javascript" src="static/js/jquery.min.js"></script>
<script type="text/javascript" src="static/js/bootstrap.min.js"></script>
    <!-- Sweet alert -->
    <script src="static/js/sweetalert.min.js"></script>
    <script type="text/javascript" src="static/js/common.js"></script>
    </body>
</html>