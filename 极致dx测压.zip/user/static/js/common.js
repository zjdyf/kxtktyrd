/**
 * 页面iframe
 * @param  {[type]} title 标题
 * @param  {[type]} url   iframe嵌套网页链接地址
 * @param  {[type]} width 自设宽度
 * @param  {[type]} hight 自设高度
 * @param  {[type]} scb   打开iframe后执行函数
 * @param  {[type]} ecb   关闭iframe后默认执行函数
 * @return {[type]}       [description]
 */
function iframe(title,url,width,height) {
	if(width==''|| width==null){
		width='60%';
	}
	if(height==''||height==null){
		height='60%';
	}
	layer.open({
      title: title,
      type: 2,
      //title: false,
      //closeBtn: 1, //不显示关闭按钮
      //shade: [0],
      area: [width, height],
      anim: 2,
      shadeClose: true,
      maxmin: true, //开启最大化最小化按钮
      shade: false,
      content: [url, 'yes'], //iframe的url，no代表不显示滚动条
      success:function() {

      },
      end: function(){ //此处用于演示

      }
    });
}
/**
 * 确认弹出框
 * @param  {[type]}   message 信息
 * @param  {[type]}   url     跳转地址，不填不跳转
 * @param  {Function} cb      回调函数
 * @return {[type]}           [description]
 */
// function sureChange(message, url, cb) {
//     window.top.index = layer.confirm(message, {
//         btn: ['确认', '取消'] //按钮
//     }, function () {
//         if (url != null && url != '') {
//             window.location = url;
//         } else {
//             try {
//                 cb();
//             } catch (ex) {

//             }
//         }
//         layer.close(window.top.index)
//     });
// }
function sureChange(message,url, cb) {
    swal({
        title: "确定要执行这个操作吗？",
        text: message,
        type: "warning",
        showCancelButton: true,
        CancelButtonText:'取消',
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        closeOnConfirm: false
    }, function () {
        //swal('', "操作成功", "success");
        if (url != null && url != '') {
            window.location = url;
        } else {
            try {
                cb();
            } catch (ex) {

            }
        }
    });
}

function sureChanges(message,url, cb) {
    swal({
        title: "确定要执行这个操作吗？",
        text: message,
        type: "warning",
        showCancelButton: true,
        // CancelButtonText:'取消',
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "时间模式",
        cancelButtonText: "积分模式",
        closeOnConfirm: false
    }, function () {
        //swal('', "操作成功", "success");
        if (url != null && url != '') {
            window.location = url;
        } else {
            try {
                cb();
            } catch (ex) {

            }
        }
    });
}
/**
 * 提示弹框
 * @param  {[type]}   msg 信息
 * @param  {[type]}   url 跳转链接，没有不跳转
 * @param  {Function} cb  回调函数
 * @return {[type]}       [description]
 */
// function lalert(msg, url, cb) {
//     window.top.index = layer.alert(msg, {
//         skin: 'layer-ext-moon'
//         , closeBtn: 0
//         , anim: 1 //动画类型
//     }, function () {
//         layer.close(window.top.index)
//         if (url != null && url != '') {
//             window.location = url;
//         } else {
//             try {
//                 cb();
//             } catch (ex) {

//             }

//         }
//     });
// }
function lalert(msg, url, cb) {
   swal({
      title: msg,
      //text: "You clicked the button!",
      type: "success"
    }, function () {
        if (url != null && url != '') {
            window.location = url;
        } else {
            try {
                cb();
            } catch (ex) {

            }
        }
    })
}
//失败弹框
function falert(msg, url, cb) {
  swal({
      title: msg,
      //text: "You clicked the button!",
      type: "error"
    }, function () {
        if (url != null && url != '') {
            window.location = url;
        } else {
            try {
                cb();
            } catch (ex) {

            }
        }
    })
}