<!-- 看你大爷
 ================================
// +----------------------------+
// | 看你大爷
// +----------------------------+
// | 看你大爷
// +----------------------------+
// | 看你大爷
// +----------------------------+
// | 看你大爷
// +----------------------------+
=================================
--> 
<?php
/**
 * 用户登录
**/
@header('Content-Type: text/html; charset=UTF-8');
include("../includes/common.php");
?>
<!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta http-equiv="X-UA-Compatible" content="ie=edge" />
	<title><?php echo $conf["title"] ?>-登录</title>
	<link rel="stylesheet" href="css/login.css">
</head>
<body>
	<head>
		<div class="login">
			
			<div class="title">
				<?php echo $conf["title"] ?>-登录
			</div>
			<form action="./login.php" method="post">
			<div class="user">
				<input type="text" name="user" value="<?php echo @$_POST['user']?>"  placeholder="请输入用户名"><span></span>
			</div>
			<div class="pass">
				<input type="password" name="pass" id="password" placeholder="请输入密码"><span></span>
			</div>
			<div class="jzmm">
				<input type="checkbox"><span>记住密码</span>
			</div>
			<div class="button">
				<button type="submit">登陆<span></span></button>
			</div>
			<div class="register">
		
				<div class="wjmm"><a href="reg.php" >立即注册</a></div>
			</div>
			</form>
		</div>
		<footer>
	
		</footer>
	</head>
</body>
</html>
<?php
if(!empty($_POST['user']) && !empty($_POST['pass'])){
   $user=daddslashes($_POST['user']);
	$pass=daddslashes($_POST['pass']);
    $rs=$DB->query("select * from user_list where user = '{$user}'");
    //
    if($res = $DB->fetch($rs)){
        if($pass == $res['pass']){
            $_SESSION['user'] = $user;
            $_SESSION['islogin'] = 1;
            $_SESSION['qq'] = $res['qq'];
            $_SESSION['zt'] = $res['sta'];
            echo "<script>alert('登陆成功！');window.location.href='./';</script>";exit;
            
        }else{
            echo "<script>window.alert('密码错误');window.location.href='./login.php'; <script>";exit;
        }
    }else{
echo "<script>window.alert('不存在的账号！');window.location.href='./login.php';</script>";exit;
    }
}elseif(isset($_GET['logout'])){
	$_SESSION['islogin'] = 0;
    echo "<script>window.alert('退出成功！');window.location.href='./login.php';</script>";exit;
}elseif($_SESSION['islogin']==1){
    echo "<script>window.alert('登陆成功！');window.location.href='./';</script>";exit;
}
?>
      <footer class="col-sm-12 text-center">
       
      </footer>
<script type="text/javascript" src="static/js/jquery.min.js"></script>
</body>
</html>
<script type="text/javascript" src="static/js/jquery.min.js"></script>
<script type="text/javascript" src="static/js/bootstrap.min.js"></script>
    <!-- Sweet alert -->
    <script src="static/js/sweetalert.min.js"></script>
    <script type="text/javascript" src="static/js/common.js"></script>
    </body>
</html>