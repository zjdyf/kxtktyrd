<?php

$title='后台管理';
include './head.php';
include("../includes/common.php"); 
$row=$DB->get_row("SELECT * FROM user_list WHERE user='".$_SESSION['user']."'");
?>
<main class="lyear-layout-content">
<div class="container-fluid"><?php
function alert($tips)
{
return '<script>layer.alert("'.$tips.'");</script>';
}
if(isset($_POST['submit'])) {
	$key=random("18");
	$sql="update`user_list` set `key` ='{$key}' where `user`='{$_SESSION['user']}'";
	if($DB->query($sql))echo(alert('你的新KEY:'.$key));
	else echo(alert($DB->error()));
}
?>
</head>
<body>
    <div class="page-top">
        <h4 id="title"><?php echo $conf["title"] ?></h4>
    </div>
    <div class="page-nav" id="a" style="">
        <div class="space-20"></div>
                    <a href="." class="btn btn-success">呼叫</a>
            &nbsp;
                    <a href="/user/km.php" class="btn btn-warning">充值</a>
        &nbsp;
                    <a href="/user/log.php" class="btn btn-danger">记录</a>
        &nbsp;
            <a href="login.php?logout" class="btn btn-default logout">退出</a>        <div class="space-20"></div>
    </div>
    <p class="page-title">key重置</p>
    <div class="page-content">
        <div class="row">
            <div class="col-sm-12">
    <div class="space-10"></div>
  <form action="./keyset.php" method="post" class="form-horizontal" role="form">
      <div class="form-group">
            <div class="col-sm-10 col-sm-offset-2">
                <div class="form-control-static text-red">
                KEY修改操作不可逆，请谨慎操作！
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-10 col-sm-offset-2">
           <input type="submit" name="submit" value="点击更换" class="btn btn-warning btn-block" class="btn btn-primary form-control"/>
            </div>
            </div>
        </div>
    </div>
</div>
      <footer class="col-sm-12 text-center">
        
      </footer>
<script type="text/javascript" src="static/js/jquery.min.js"></script>
</body>
</html>
<script type="text/javascript" src="static/js/jquery.min.js"></script>
<script type="text/javascript" src="static/js/bootstrap.min.js"></script>

    <!-- Sweet alert -->
    <script src="static/js/sweetalert.min.js"></script>
    <script type="text/javascript" src="static/js/common.js"></script>
    </body>
</html>